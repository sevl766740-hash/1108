'use strict';
const { app, BrowserWindow, Menu, ipcMain, net, session } = require('electron');
const path = require('path'); const fs = require('fs'); const { spawn } = require('child_process');
const role = require('./role');

app.disableHardwareAcceleration();
const args = role.parseArgs(process.argv.slice(1));

if (args.role) {
  // Probe B instance: no window, only the single-instance experiment
  role.runRole(args, role.makeMech('electron', args.ud));
} else {
  let win = null;
  const baseDir = () => path.join(app.getPath('userData'), 'probe-bc');
  const send = (l) => { if (win && !win.isDestroyed()) win.webContents.send('progress', l); };
  app.whenReady().then(() => {
    win = new BrowserWindow({ width: 980, height: 760, title: 'Win7 探针 B 与 C', webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
    win.setMenuBarVisibility(false);
    win.webContents.on('context-menu', (_e, p) => { if (!p.isEditable && !p.selectionText) return; Menu.buildFromTemplate([{ role: 'copy', label: '复制' }, { role: 'selectAll', label: '全选' }]).popup(); });
    win.loadFile(path.join(__dirname, 'index.html'));
  });
  app.on('window-all-closed', () => app.quit());
  ipcMain.handle('ping', () => 1);
  ipcMain.handle('env', () => [
    '平台：' + process.platform + ' ' + process.arch + '，系统版本：' + require('os').release(),
    'CPU：' + (require('os').cpus()[0] || {}).model + ' × ' + require('os').cpus().length + '；内存 ' + Math.round(require('os').totalmem() / 1048576) + ' MB',
    'Electron/Chrome/Node：' + process.versions.electron + ' / ' + process.versions.chrome + ' / ' + process.versions.node,
    '硬件加速：已被本探针禁用', '工作目录：' + baseDir()
  ]);
  ipcMain.handle('run-b', async () => {
    fs.mkdirSync(baseDir(), { recursive: true });
    const { runB } = require('./driver-b');
    await runB({ outDir: baseDir(), mech: 'electron', log: send, spawnRole: (a) => spawn(process.execPath, Object.entries(a).map(([k, v]) => '--' + k + '=' + v), { stdio: 'ignore', windowsHide: true }) });
    return true;
  });
  ipcMain.handle('run-c', async (_e, quick) => {
    fs.mkdirSync(baseDir(), { recursive: true });
    const { runAll } = require('./c-engine');
    await runAll({
      dir: baseDir(), quick: !!quick, log: send,
      client: (url, onData) => { const req = net.request({ url: url, session: session.defaultSession, useSessionCookies: false }); req.on('response', (res) => res.on('data', (d) => onData(d.toString()))); req.on('error', () => {}); req.end(); return () => { try { req.abort(); } catch (e) { /* ignore */ } }; },
      sendBatch: (n) => { if (win && !win.isDestroyed()) win.webContents.send('batch', n); },
      ipcStats: (t0, t1) => win.webContents.executeJavaScript('window.__takeStats(' + t0 + ',' + t1 + ')')
    });
    return true;
  });
  ipcMain.handle('save-report', (_e, text) => { const f = path.join(app.getPath('userData'), 'probe-bc-report-' + new Date().toISOString().replace(/[:.]/g, '-') + '.txt'); fs.writeFileSync(f, text, 'utf8'); return f; });
}

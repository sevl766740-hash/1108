'use strict';
var $ = function (id) { return document.getElementById(id); };
var lines = [];
function log(t) { lines.push(t); var ta = $('rep'); ta.value = lines.join('\n'); ta.scrollTop = ta.scrollHeight; }
window.native.onProgress(log);
var nb = 0; window.native.onBatch(function (n) { nb += n; $('batch').textContent = '已收到模拟流事件 ' + nb; });
window.__pings = [];
(async function loop() { while (true) { var d = Date.now(), t = performance.now(); await window.native.ping(); window.__pings.push({ t: d, rtt: performance.now() - t }); if (window.__pings.length > 20000) window.__pings.splice(0, 5000); await new Promise(function (r) { setTimeout(r, 50); }); } })();
window.__takeStats = function (t0, t1) { return window.__pings.filter(function (e) { return e.t >= t0 && e.t <= t1; }).map(function (e) { return e.rtt; }); };
(async function () { log('== Win7 探针 B 与 C v1 =='); log('时间：' + new Date().toISOString()); (await window.native.env()).forEach(function (l) { log('  ' + l); }); })();
async function run(btn, label, fn) {
  $(btn).disabled = true; log('\n########## ' + label + ' 开始 ##########');
  try { await fn(); } catch (e) { log('出错：' + e.message); }
  await new Promise(function (r) { setTimeout(r, 800); }); log('########## ' + label + ' 结束 ##########'); $(btn).disabled = false;
}
$('bb').onclick = function () { run('bb', '探针 B', function () { return window.native.runB(); }); };
$('bc').onclick = function () { run('bc', '探针 C', function () { return window.native.runC($('quick').checked); }); };
$('cp').onclick = function () { var ta = $('rep'); ta.focus(); ta.select(); try { document.execCommand('copy'); $('cp').textContent = '已复制'; } catch (e) { $('cp').textContent = '请手动复制'; } };
$('sv').onclick = async function () { var f = await window.native.saveReport(lines.join('\n')); $('svmsg').textContent = '已保存到：' + f; };

'use strict';
// Data-layer-like operations, in two flavours: async (main process, option A) and sync (worker thread, option B).
const fs = require('fs'); const fsp = fs.promises; const path = require('path');
const now = () => Number(process.hrtime.bigint()) / 1e6;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const DELAYS = [5, 10, 20, 40, 80, 160, 320, 640, 725];
const RETRY = ['EPERM', 'EBUSY', 'EACCES'];
const LINE = 'x'.repeat(1000) + '\n';
const BUF64 = Buffer.alloc(64 * 1024, 0x61);
const BUF4 = Buffer.alloc(4096, 0x62);

function prepareBigFile(file) {
  if (fs.existsSync(file)) return;
  const lines = []; const pad = 'z'.repeat(150);
  for (let i = 0; i < 40000; i++) lines.push(JSON.stringify({ t: 'msg', i: i, p: pad }));
  fs.writeFileSync(file, lines.join('\n') + '\n');
}
async function renameRetryAsync(a, b) {
  for (let k = 0; ; k++) { try { await fsp.rename(a, b); return; } catch (e) { if (!RETRY.includes(e.code) || k >= DELAYS.length) throw e; await sleep(DELAYS[k]); } }
}
function renameRetrySync(a, b) {
  const sl = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
  for (let k = 0; ; k++) { try { fs.renameSync(a, b); return; } catch (e) { if (!RETRY.includes(e.code) || k >= DELAYS.length) throw e; sl(DELAYS[k]); } }
}

// ---- async flavour: every op returns its latency in ms
const asyncOps = {
  async append(ctx) { const t = now(); await ctx.fh.write(LINE); await ctx.fh.sync(); return now() - t; },
  async replace(ctx) {
    const t = now(); const tmp = ctx.target + '.tmp';
    const fh = await fsp.open(tmp, 'w'); await fh.write(BUF64); await fh.sync(); await fh.close();
    await renameRetryAsync(tmp, ctx.target); return now() - t;
  },
  async parse(ctx) { const t = now(); const s = await fsp.readFile(ctx.bigFile, 'utf8'); for (const ln of s.split('\n')) if (ln) JSON.parse(ln); return now() - t; },
  async flood(ctx, k) {
    const t = now(); const fh = await fsp.open(ctx.dir + path.sep + 'flood' + k + '.bin', 'w');
    await fh.write(BUF4); await fh.sync(); await fh.close(); return now() - t;
  }
};
// ---- sync flavour (worker thread only)
const syncOps = {
  append(ctx) { const t = now(); fs.writeSync(ctx.fd, LINE); fs.fsyncSync(ctx.fd); return now() - t; },
  replace(ctx) {
    const t = now(); const tmp = ctx.target + '.tmp';
    const fd = fs.openSync(tmp, 'w'); fs.writeSync(fd, BUF64); fs.fsyncSync(fd); fs.closeSync(fd);
    renameRetrySync(tmp, ctx.target); return now() - t;
  },
  parse(ctx) { const t = now(); const s = fs.readFileSync(ctx.bigFile, 'utf8'); for (const ln of s.split('\n')) if (ln) JSON.parse(ln); return now() - t; }
};
// which loops a phase runs
const PHASES = { baseline: [], append: ['append'], replace: ['replace'], parse: ['parse'], flood: ['flood'], mixed: ['append', 'replace', 'parse'] };
module.exports = { asyncOps, syncOps, PHASES, prepareBigFile, now, sleep };

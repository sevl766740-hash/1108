'use strict';
// Probe B: one process = one instance taking part in the single-instance experiment.
const fs = require('fs'); const path = require('path'); const net = require('net'); const crypto = require('crypto');
function parseArgs(argv) { const o = {}; for (const a of argv) { const m = /^--([a-z-]+)=(.*)$/.exec(a); if (m) o[m[1]] = m[2]; } return o; }
function makeMech(name, ud) {
  if (name === 'electron') {
    const { app } = require('electron'); app.setPath('userData', ud);   // the lock is keyed by userData
    return {
      async acquire() { return app.requestSingleInstanceLock(); },
      onSecond(cb) { app.on('second-instance', (e, argv, cwd) => cb({ argc: argv.length, cwd: cwd })); },
      quit() { app.quit(); }, exit(c) { app.exit(c); }
    };
  }
  // 'tcp': only used to dry-run the driver under plain Node (it is NOT a candidate mechanism)
  const port = 20000 + parseInt(crypto.createHash('md5').update(path.resolve(ud).toLowerCase()).digest('hex').slice(0, 4), 16) % 20000;
  return {
    acquire() { return new Promise((res) => { const srv = net.createServer(() => {}); srv.once('error', () => res(false)); srv.listen(port, '127.0.0.1', () => res(true)); }); },
    onSecond() {}, quit() { process.exit(0); }, exit(c) { process.exit(c); }
  };
}
async function runRole(o, mech) {
  const logFile = o.out + path.sep + o.label + '.log';
  const log = (ev, extra) => fs.appendFileSync(logFile, JSON.stringify(Object.assign({ t: Date.now(), pid: process.pid, ev: ev }, extra || {})) + '\n');
  log('start', { role: o.role });
  const t0 = Date.now(); const got = await mech.acquire(); const ms = Date.now() - t0;
  log('lock', { got: got, ms: ms });
  if (!got) { log('held-exit'); mech.exit(3); return; }
  mech.onSecond((x) => log('second-instance', x));
  if (o.role === 'contender') { setTimeout(() => { log('quit'); mech.quit(); }, parseInt(o['hold-ms'] || '1500', 10)); return; }
  log('ready');
  if (o['exit-after-ms']) setTimeout(() => { log('quit'); mech.quit(); }, parseInt(o['exit-after-ms'], 10));
  if (o['hang-after-ms']) setTimeout(() => { log('hang-start'); const end = Date.now() + parseInt(o['hang-ms'], 10); while (Date.now() < end) { /* main thread busy */ } log('hang-end'); }, parseInt(o['hang-after-ms'], 10));
}
module.exports = { parseArgs, makeMech, runRole };
if (require.main === module) { const o = parseArgs(process.argv.slice(2)); runRole(o, makeMech(o.mech || 'tcp', o.ud)); }

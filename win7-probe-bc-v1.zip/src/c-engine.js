'use strict';
// Probe C engine: runs the same load in two ways while measuring the main process.
const fs = require('fs'); const fsp = fs.promises; const path = require('path'); const dns = require('dns');
const { spawn } = require('child_process'); const { Worker } = require('worker_threads');
const { asyncOps, PHASES, prepareBigFile, now } = require('./c-ops');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function pct(a, p) { if (!a.length) return null; const s = a.slice().sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(p / 100 * s.length))]; }
const f1 = (x) => (x == null ? '无' : x.toFixed(1));
function rmrf(p) { try { fs.rmSync(p, { recursive: true, force: true }); } catch (e) { /* ignore */ } }

async function runAll(env) {
  // env: { dir, quick, log, client(url,onData)->close, sendBatch?(n), ipcStats?(t0,t1)->Promise<number[]> }
  const log = env.log; const phaseMs = env.quick ? 5000 : 12000;
  const dir = path.join(env.dir, 'probe-c-' + Date.now()); fs.mkdirSync(dir, { recursive: true });
  prepareBigFile(path.join(dir, 'big.jsonl'));
  // --- continuous measurements (time-stamped, sliced per phase afterwards)
  const lag = [], probeStat = [], probeDns = [], rx = []; let rxBatch = 0;
  let last = now(); const lagTimer = setInterval(() => { const n = now(); lag.push({ t: Date.now(), v: n - last - 10 }); last = n; }, 10);
  const probeTimer = setInterval(async () => {
    const t = now(); try { await fsp.stat(path.join(dir, 'big.jsonl')); probeStat.push({ t: Date.now(), v: now() - t }); } catch (e) { /* ignore */ }
    const t2 = now(); dns.lookup('localhost', () => probeDns.push({ t: Date.now(), v: now() - t2 }));
  }, 100);
  // --- simulated stream from a separate process
  const srv = spawn(process.execPath, [path.join(__dirname, 'sse-server.js'), '10'], { env: Object.assign({}, process.env, { ELECTRON_RUN_AS_NODE: '1' }), stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true });
  const port = await new Promise((res) => { let b = ''; srv.stdout.on('data', (d) => { b += d; const m = /PORT (\d+)/.exec(b); if (m) res(parseInt(m[1], 10)); }); });
  let buf = '';
  const closeStream = env.client('http://127.0.0.1:' + port + '/', (chunk) => {
    buf += chunk; const parts = buf.split('\n\n'); buf = parts.pop(); const t = Date.now();
    for (const p of parts) { const m = /"n":(\d+)/.exec(p); if (m) rx.push({ t: t, late: t - parseInt(m[1], 10) }); }
  });
  const batchTimer = setInterval(() => { if (env.sendBatch) env.sendBatch(rx.length - rxBatch); rxBatch = rx.length; }, 100);
  await sleep(1500);
  const worker = new Worker(path.join(__dirname, 'c-worker.js'));

  async function runA(phase) { // option A: async fs in the main process
    const ctx = { dir: dir, target: path.join(dir, 'a-target.json'), bigFile: path.join(dir, 'big.jsonl') };
    fs.writeFileSync(ctx.target, 'x'); const end = Date.now() + phaseMs; const stats = {}; const loops = [];
    for (const kind of PHASES[phase]) {
      if (kind === 'flood') for (let k = 0; k < 8; k++) loops.push((async () => { while (Date.now() < end) (stats.flood = stats.flood || []).push(await asyncOps.flood(ctx, k)); })());
      else loops.push((async () => {
        const c = Object.assign({}, ctx); if (kind === 'append') c.fh = await fsp.open(path.join(dir, 'a-append.jsonl'), 'a');
        while (Date.now() < end) (stats[kind] = stats[kind] || []).push(await asyncOps[kind](c));
        if (c.fh) await c.fh.close();
      })());
    }
    await Promise.all(loops); return stats;
  }
  function runB(phase) { // option B: the same operations on a worker thread
    return new Promise((res) => { worker.once('message', (m) => res(m.stats)); worker.postMessage({ cmd: 'phase', phase: phase, ms: phaseMs, dir: dir }); });
  }
  const win = (arr, t0, t1, key) => arr.filter((e) => e.t >= t0 && e.t <= t1).map((e) => e[key || 'v']);
  const rows = [];
  for (const phase of Object.keys(PHASES)) {
    for (const impl of (phase === 'baseline' ? ['—'] : ['A', 'B'])) {
      log('  运行：阶段 ' + phase + '，方案 ' + impl + '（' + phaseMs / 1000 + ' 秒）…');
      const t0 = Date.now(); const stats = impl === 'B' ? await runB(phase) : (impl === 'A' ? await runA(phase) : (await sleep(phaseMs), {}));
      const t1 = Date.now(); await sleep(400);
      const L = win(lag, t0, t1), S = win(probeStat, t0, t1), D = win(probeDns, t0, t1), R = win(rx, t0, t1, 'late');
      let gap = 0, prev = null; for (const e of rx) if (e.t >= t0 && e.t <= t1) { if (prev !== null) gap = Math.max(gap, e.t - prev); prev = e.t; }
      const ipc = env.ipcStats ? await env.ipcStats(t0, t1) : [];
      rows.push({ phase: phase, impl: impl, L: L, S: S, D: D, R: R, gap: gap, ipc: ipc, stats: stats });
    }
  }
  clearInterval(lagTimer); clearInterval(probeTimer); clearInterval(batchTimer); closeStream(); srv.kill(); worker.terminate(); rmrf(dir);

  log('\n== 探针 C 结果（每个阶段 ' + phaseMs / 1000 + ' 秒；A＝主进程异步 fs，B＝工作线程）==');
  log('说明：事件循环滞后＝主进程每 10 ms 一次的定时器偏差；流到达延迟＝本地模拟流中每个事件从服务端实际发出到被主进程收到的时间；IPC 往返＝界面每 50 ms 向主进程发一次请求的往返；探针 stat／dns＝主进程同时发出的小文件与域名解析请求的耗时（反映线程池排队）。');
  for (const r of rows) {
    log('\n[' + r.phase + ' / ' + r.impl + ']');
    log('  事件循环滞后：p50 ' + f1(pct(r.L, 50)) + '，p95 ' + f1(pct(r.L, 95)) + '，p99 ' + f1(pct(r.L, 99)) + '，最大 ' + f1(pct(r.L, 100)) + ' ms；超过 50 ms 的 ' + r.L.filter((x) => x > 50).length + ' 次，超过 100 ms 的 ' + r.L.filter((x) => x > 100).length + ' 次');
    log('  流到达延迟：p50 ' + f1(pct(r.R, 50)) + '，p95 ' + f1(pct(r.R, 95)) + '，最大 ' + f1(pct(r.R, 100)) + ' ms；最大到达间隔 ' + r.gap + ' ms；收到 ' + r.R.length + ' 个事件');
    log('  IPC 往返：' + (r.ipc.length ? 'p50 ' + f1(pct(r.ipc, 50)) + '，p95 ' + f1(pct(r.ipc, 95)) + '，最大 ' + f1(pct(r.ipc, 100)) + ' ms（' + r.ipc.length + ' 次）' : '未测'));
    log('  同时发出的小请求：stat p95 ' + f1(pct(r.S, 95)) + '，最大 ' + f1(pct(r.S, 100)) + ' ms；dns.lookup p95 ' + f1(pct(r.D, 95)) + '，最大 ' + f1(pct(r.D, 100)) + ' ms');
    for (const k of Object.keys(r.stats)) { const a = r.stats[k]; log('  操作 ' + k + '：' + a.length + ' 次，中位 ' + f1(pct(a, 50)) + '，p95 ' + f1(pct(a, 95)) + '，最大 ' + f1(pct(a, 100)) + ' ms'); }
  }
  log('\n参考（暂定，不是自动判定）：方案 A 的 mixed 阶段若事件循环滞后 p99 低于约 50 ms、流到达延迟最大值低于约 200 ms、IPC 往返 p95 低于约 50 ms，则不需要引入工作线程；parse 阶段若在 A 下滞后明显，说明 CPU 型工作（折叠大文件）需要放进工作线程，与 fsync 无关。');
}
module.exports = { runAll };

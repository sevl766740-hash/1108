'use strict';
// Probe B driver: starts and kills instances, and reads what each one logged.
const fs = require('fs'); const path = require('path');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function runB(env) {
  const log = env.log; const out = path.join(env.outDir, 'b-' + Date.now()); fs.mkdirSync(out, { recursive: true });
  let seq = 0;
  const readLog = (label) => { try { return fs.readFileSync(path.join(out, label + '.log'), 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)); } catch (e) { return []; } };
  const waitEv = async (label, ev, ms) => { const end = Date.now() + ms; while (Date.now() < end) { const f = readLog(label).find((e) => e.ev === ev); if (f) return f; await sleep(50); } return null; };
  const waitExit = async (info, ms) => { const end = Date.now() + ms; while (!info.exited && Date.now() < end) await sleep(50); return info.exited; };
  const start = (role, ud, extra) => {
    const label = role + '-' + (++seq);
    const child = env.spawnRole(Object.assign({ role: role, label: label, ud: ud, out: out, mech: env.mech }, extra || {}));
    const info = { label: label, child: child, pid: child.pid, exited: false, code: null, t0: Date.now() };
    child.on('exit', (c) => { info.exited = true; info.code = c; info.tExit = Date.now(); });
    return info;
  };
  const kill = (info) => { if (!info.exited) { try { info.child.kill('SIGKILL'); } catch (e) { /* ignore */ } } };
  const alive = (pid) => { try { process.kill(pid, 0); return true; } catch (e) { return false; } };
  const mkud = (name) => { const d = path.join(out, 'ud-' + name); fs.mkdirSync(d, { recursive: true }); return d; };
  const lockOf = (info) => readLog(info.label).find((e) => e.ev === 'lock');
  const verdict = (ok) => (ok ? '符合 D1 预期' : '**不符合 D1 预期**');
  const all = [];

  // B1 basic
  log('\n== B1 基本：A 持有锁时，B 能否拿到锁 ==');
  { const ud = mkud('b1'); const A = start('holder', ud);
    if (!(await waitEv(A.label, 'ready', 30000))) log('  A 没有在 30 秒内拿到锁，本项无法判定');
    else {
      const B = start('contender', ud); await waitExit(B, 30000); const l = lockOf(B); const sec = readLog(A.label).find((e) => e.ev === 'second-instance');
      const ok = l && l.got === false; all.push(ok);
      log('  B 拿到锁：' + (l ? l.got : '无记录') + '；B 的获取调用耗时 ' + (l ? l.ms : '?') + ' ms；B 的退出码 ' + B.code + '；A 收到 second-instance 通知：' + (sec ? '是' : '否') + ' → ' + verdict(ok));
    }
    kill(A); await waitExit(A, 5000); }

  // B2 normal exit
  log('\n== B2 A 正常退出后，B 能否拿到锁 ==');
  { const ud = mkud('b2'); const A = start('holder', ud, { 'exit-after-ms': '3500' });
    if (!(await waitEv(A.label, 'ready', 30000))) log('  A 没有拿到锁，本项无法判定');
    else {
      const B = start('contender', ud); await waitExit(B, 20000); const lb = lockOf(B);
      await waitExit(A, 20000); const tExit = A.tExit; const C = start('contender', ud); await waitExit(C, 20000); const lc = lockOf(C);
      const ok = lb && lb.got === false && lc && lc.got === true; all.push(ok);
      log('  A 仍在运行时 B 拿到锁：' + (lb ? lb.got : '无记录') + '；A 退出后 C 拿到锁：' + (lc ? lc.got : '无记录') + (lc && tExit ? '（A 退出后 ' + (lc.t - tExit) + ' ms 内）' : '') + ' → ' + verdict(ok));
    }
    kill(A); }

  // B3 killed
  log('\n== B3 A 被强制终止后，B 多久能拿到锁 ==');
  { const ud = mkud('b3'); const A = start('holder', ud);
    if (!(await waitEv(A.label, 'ready', 30000))) log('  A 没有拿到锁，本项无法判定');
    else {
      const tk = Date.now(); kill(A); await waitExit(A, 5000); let got = false, ms = null, tries = 0;
      while (!got && Date.now() - tk < 10000) { tries++; const B = start('contender', ud); await waitExit(B, 20000); const l = lockOf(B); if (l && l.got) { got = true; ms = l.t - tk; } else await sleep(200); }
      all.push(got && tries === 1);
      log('  强杀后第一次尝试即拿到锁：' + (got && tries === 1) + '；共尝试 ' + tries + ' 次；从强杀到拿到锁 ' + (ms == null ? '超过 10 秒仍未拿到' : ms + ' ms') + ' → ' + verdict(got && tries === 1) + '（"第一次尝试"受进程启动耗时影响，若不是第一次，看最后一项时间）');
    } }

  // B4 spellings
  log('\n== B4 同一目录的不同写法是否得到同一把锁（期望：等价写法被拒，另一个目录能拿到锁）==');
  { const ud = mkud('b4'); fs.mkdirSync(path.join(ud, 'sub'), { recursive: true }); fs.mkdirSync(ud + '-other', { recursive: true });
    const A = start('holder', ud);
    if (!(await waitEv(A.label, 'ready', 30000))) log('  A 没有拿到锁，本项无法判定');
    else {
      const sep = path.sep;
      const variants = [['同一路径（对照）', ud, false], ['全部大写', ud.toUpperCase(), false], ['全部小写', ud.toLowerCase(), false], ['末尾加分隔符', ud + sep, false], ['正斜杠写法', ud.replace(/\\/g, '/'), false], ['含 .. 片段', ud + sep + 'sub' + sep + '..', false], ['另一个目录（对照，应能拿到锁）', ud + '-other', true]];
      for (const [name, v, expectGot] of variants) {
        const B = start('contender', v); await waitExit(B, 30000); const l = lockOf(B);
        log('  ' + name + '：拿到锁 ' + (l ? l.got : '无记录') + (l && l.got !== expectGot && !expectGot ? '  → 该写法被当作不同的锁，调用前必须自己规范化路径' : '') + (l && l.got === expectGot ? '  → 符合预期' : ''));
      }
    }
    kill(A); await waitExit(A, 5000); }

  // B5 repeated
  log('\n== B5 A 存活期间，连续 8 次尝试 ==');
  { const ud = mkud('b5'); const A = start('holder', ud);
    if (!(await waitEv(A.label, 'ready', 30000))) log('  A 没有拿到锁，本项无法判定');
    else { let held = 0; for (let i = 0; i < 8; i++) { const B = start('contender', ud); await waitExit(B, 30000); const l = lockOf(B); if (l && l.got === false) held++; await sleep(200); }
      all.push(held === 8); log('  8 次尝试中被拒绝 ' + held + ' 次，其余拿到了锁 ' + (8 - held) + ' 次 → ' + verdict(held === 8)); }
    kill(A); await waitExit(A, 5000); }

  // B6 hung holder
  log('\n== B6 A 的主线程卡死时，B 会怎样（期望：被拒，且不能杀掉或抢占 A）==');
  { const ud = mkud('b6'); const A = start('holder', ud, { 'hang-after-ms': '1500', 'hang-ms': '8000' });
    if (!(await waitEv(A.label, 'ready', 30000))) log('  A 没有拿到锁，本项无法判定');
    else if (!(await waitEv(A.label, 'hang-start', 20000))) log('  A 没有进入卡死状态，本项无法判定');
    else {
      await sleep(1000); const tb = Date.now(); const B = start('contender', ud); const done = await waitExit(B, 40000); const l = lockOf(B);
      const aliveAfter = alive(A.pid);
      log('  B 的结果：拿到锁 ' + (l ? l.got : '无记录') + '；获取调用耗时 ' + (l ? l.ms : '?') + ' ms；B ' + (done ? '在 ' + (B.tExit - tb) + ' ms 后退出，退出码 ' + B.code : '40 秒内没有退出（可能在等待或弹出了对话框）') + '；B 返回时 A 进程仍然存活：' + aliveAfter);
      if (!done) kill(B);
      await waitEv(A.label, 'hang-end', 30000); await sleep(500);
      const C = start('contender', ud); await waitExit(C, 30000); const lc = lockOf(C); const sec = readLog(A.label).filter((e) => e.ev === 'second-instance').length;
      const ok = l && l.got === false && aliveAfter && lc && lc.got === false; all.push(ok);
      log('  A 恢复后：A 仍持有锁（新的 C 被拒）：' + (lc ? lc.got === false : '无记录') + '；A 收到的 second-instance 通知共 ' + sec + ' 次 → ' + verdict(ok));
    }
    kill(A); await waitExit(A, 5000); }

  // B7 race
  log('\n== B7 同时启动两个实例（6 轮；期望每轮恰好一个拿到锁）==');
  { let good = 0, none = 0, both = 0;
    for (let i = 0; i < 6; i++) { const ud = mkud('b7-' + i); const X = start('holder', ud); const Y = start('holder', ud); await sleep(6000);
      const n = [X, Y].filter((p) => readLog(p.label).some((e) => e.ev === 'ready')).length; if (n === 1) good++; else if (n === 0) none++; else both++; kill(X); kill(Y); await waitExit(X, 5000); await waitExit(Y, 5000); }
    all.push(both === 0 && none === 0); log('  恰好一个：' + good + ' 轮；两个都拿到：' + both + ' 轮；两个都没拿到：' + none + ' 轮 → ' + verdict(both === 0 && none === 0)); }

  // B8 independent
  log('\n== B8 不同数据目录互不影响 ==');
  { const A = start('holder', mkud('b8a')); const B = start('holder', mkud('b8b')); const a = await waitEv(A.label, 'ready', 30000); const b = await waitEv(B.label, 'ready', 30000);
    all.push(!!(a && b)); log('  两个实例都拿到各自的锁：' + !!(a && b) + ' → ' + verdict(!!(a && b))); kill(A); kill(B); await waitExit(A, 5000); await waitExit(B, 5000); }

  log('\n汇总：' + all.filter(Boolean).length + ' / ' + all.length + ' 项符合预期（B4 为信息项，不计入）。日志目录：' + out);
}
module.exports = { runB };

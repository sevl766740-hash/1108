'use strict';
// Separate process: emits one SSE event every `rate` ms with its *scheduled* send time, so that
// the receiver can measure how late each event arrives. Kept out of the app's process on purpose.
const http = require('http');
const rate = parseInt(process.argv[2] || '10', 10);
const srv = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' });
  let i = 0; const t0 = Date.now();
  // Catch-up scheduler: always send every event that is due, so the server itself never drifts behind its schedule.
  // 's' is the scheduled time, 'n' the actual send time; the receiver measures lateness against 'n'.
  const timer = setInterval(() => {
    const t = Date.now();
    while (t0 + i * rate <= t) { res.write('data: {"i":' + i + ',"s":' + (t0 + i * rate) + ',"n":' + Date.now() + '}\n\n'); i++; }
  }, 2);
  req.on('close', () => clearInterval(timer));
});
srv.listen(0, '127.0.0.1', () => console.log('PORT ' + srv.address().port));

'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('native', {
  ping: () => ipcRenderer.invoke('ping'), env: () => ipcRenderer.invoke('env'),
  runB: () => ipcRenderer.invoke('run-b'), runC: (q) => ipcRenderer.invoke('run-c', q),
  saveReport: (t) => ipcRenderer.invoke('save-report', t),
  onProgress: (cb) => { ipcRenderer.removeAllListeners('progress'); ipcRenderer.on('progress', (_e, l) => cb(l)); },
  onBatch: (cb) => { ipcRenderer.removeAllListeners('batch'); ipcRenderer.on('batch', (_e, n) => cb(n)); }
});

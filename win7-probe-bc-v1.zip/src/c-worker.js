'use strict';
// Option B: the same operations executed on a worker thread.
const { parentPort } = require('worker_threads');
const fs = require('fs'); const fsp = fs.promises; const path = require('path');
const { asyncOps, syncOps, PHASES, prepareBigFile, now } = require('./c-ops');
parentPort.on('message', async (m) => {
  if (m.cmd !== 'phase') return;
  const dir = m.dir; const ctx = { dir: dir, target: path.join(dir, 'w-target.json'), bigFile: path.join(dir, 'big.jsonl') };
  prepareBigFile(ctx.bigFile); fs.writeFileSync(ctx.target, 'x');
  const stats = {}; const end = Date.now() + m.ms; const kinds = PHASES[m.phase];
  const loops = [];
  for (const kind of kinds) {
    if (kind === 'flood') {
      for (let k = 0; k < 8; k++) loops.push((async () => { while (Date.now() < end) { (stats.flood = stats.flood || []).push(await asyncOps.flood(ctx, k)); } })());
    } else {
      // sync ops block this worker only; yield to its event loop between operations
      loops.push((async () => {
        let fd = null; if (kind === 'append') fd = fs.openSync(path.join(dir, 'w-append.jsonl'), 'a');
        const c = Object.assign({}, ctx, { fd: fd });
        while (Date.now() < end) { (stats[kind] = stats[kind] || []).push(syncOps[kind](c)); await new Promise((r) => setImmediate(r)); }
        if (fd !== null) fs.closeSync(fd);
      })());
    }
  }
  await Promise.all(loops);
  parentPort.postMessage({ cmd: 'done', stats: stats });
});
